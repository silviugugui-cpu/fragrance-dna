# Perfume house articles data handoff

Database for the Fragrantiq articles section. It is a companion database and does not modify `data/generated/fragrancedna.sqlite`.

## Contents

- 80 selected perfume houses: 35 niche, 10 dupe, and 35 designer.
- 8857 fragrance records copied from the current Fragrantiq catalog using `record_id` and `canonical_key` as stable source joins.
- 8216 records point to an existing product image in the Fragrantiq project. Images stay in `public/images/perfumes`; the database stores their site paths. Records without an image remain present and have `image_exists = 0`.
- 80 original, logo-free editorial SVG illustrations in `brand-art/`; the integration destination is `public/images/brand-editorial/`.
- 13902 note/accord-based territory suggestions (5033 unique primary candidates). These are drafts with evidence terms, source URL, confidence, method ID, and review status.
- 2124 explicit dupe-similarity records, including records marked `pending_research` rather than treating unknown as “no resemblance”. Current statuses: {'brand_claimed_inspired_by': 3, 'documented_resemblance': 7, 'pending_research': 2114}.

## Important tables

- `brands`: house selection, official-site candidate URL, editorial description draft, and source-catalog record count.
- `brand_art`: local SVG path, alt text, method, and motifs.
- `fragrances`: catalog records with source URL, year, perfumer where present, accords, notes, description, image path, and original source IDs.
- `featured_fragrances`: the representative perfume from the 80-house workbook and its exact/curated/ambiguous/not-found catalog match.
- `dupe_similarities`: explicit reference brand/perfume, relation type, source, source type, confidence, and research status.
- `olfactory_territories`, `dna_axes`, `dna_model_metadata`: exact definitions imported from the provided OlfactiveDNA export, plus the live runtime affinity-engine rules.
- `fragrance_territory_suggestions`: product-side editorial candidates derived from notes/accords. These do not use user DNA scores.

## OlfactiveDNA boundary

The 11 canonical dashboard axes and 10 territories match the provided JSON and the project runtime. The runtime territory-affinity calculation describes a user's affinity to each territory; it does not classify a perfume. Product territory rows therefore use the separate `editorial-note-accord-rule-v1` method, include evidence and confidence, and start in `editorial_review_pending`. No fragrance axis profile is fabricated from the user-preference formulas.

## Dupe likeness

The `dupe_similarities` table has a row for every catalog perfume in the selected dupe houses. States mean:

- `brand_claimed_inspired_by`: the brand itself names the reference.
- `documented_resemblance`: an external comparison source reports the resemblance; source type distinguishes editorial, community, and comparison database.
- `pending_research`: no source-backed pair was recorded yet; this does not mean “no resemblance”.
- `reviewed_no_match`: reserved for a future explicit review that finds no well-supported match.

## Before public release

House descriptions and official-site candidate domains carry review status in the database. Verify/replace these editorial drafts and website links from the first-party brand pages. The source product catalogue has coverage gaps: a few representative perfumes are missing or have ambiguous edition variants; consult `featured_fragrances.match_status` before showing a missing item as researched. Product image file paths stay rooted in the existing project.

## Integration paths

The staged folder is the source package. Copy the SQLite file to `data/generated/perfume-house-articles.sqlite` and the contents of `brand-art/` to `public/images/brand-editorial/` in the Fragrantiq project. No existing database rows or product photos need to be rewritten.
